<template>
       
</template>

<script>

  import globs from '../../../tunepik/attack.js'

    export default {

        name    : "AudioBodyBuilder",
        data    : () => {

          return {

            screen : globs.app.isMobile

          }

        }

    }
</script>

<style scoped>

</style>
