<template>
    <span class="" v-if="post.getPost().text != ''">
      <span class="app-post-text">{{ post.getPost().text }}</span>
    </span>
</template>

<script>

  import globs from '../../../tunepik/attack.js'

    export default {

        name    : "TextBodyBuilder",
        data    : () => {

          return {

            screen : globs.app.isMobile,

          }

        }, 
        props : ['post']

    };
</script>

<style scoped>


</style>
