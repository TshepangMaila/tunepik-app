<template>

		<div class="wrapper">
			
			<center>

        <div class="media">
          
          <div class="media-left ml-2 align-self-center">
            
            <div v-if="makeIcon">
              
              <a @click="playpause(timeView)" >

                <span >
                  <i class="fa fa-pause app-fa"></i>
                </span>
                
              </a>

            </div>

            <div v-else>

              <a @click="playpause(timeView)" >

                <span >
                  <i class="fa fa-play app-fa"></i>
                </span>

              </a>

            </div>

            
            

            <div class="media-info-body mt-1">
              <div class="media-text info-views">
                {{ timeView }}
              </div>
            </div> 

          </div>

          <div class="media-body pr-2">

            <div class="wave-surf" :id="postId" ref="wave"></div>
            
          </div>

        </div>

			</center>
			<!-- <div class="media-info-body">
				<div class="media-text info-views">
					{{ timeView }}
				</div>
			</div> -->

		</div>
       
</template>

<script>

  import globs from '../../../tunepik/attack.js'
  // import VueWaveSurfer from 'vue-wave-surfer'
  import WaveSurfer from 'wavesurfer.js'

    export default {

        name    		: "AudioBodyBuilder",
        components	: {

        	// VueWaveSurfer

        },
        data    		: function(){

          return {
            screen               : globs.app.isMobile,
      			isPlayerReady        : false,
      			timeView 			 : '00:00',
            playing        : false,

          }

        },
        props    : ['post'],
        computed : {

        	player : function(){

        		return WaveSurfer.create(this.options);

        	},
          options : function(){

              return {

                container : this.$refs.wave/*`#${this.postId}`*/,
                waveColor : '#5bc0de',
                progressColor : '#111',
                barWidth: 2,
                barHeight: 30,
                barRadius: 3,
                barGap: 2,
                height: 40,
                interact: true

              }

            },
            postId : function(){

                return `surfer-${this.post.getPost().id}`;

            },
            makeIcon : function(){
              return this.playing
            }

        },
        methods  : {

        	isReady   : function(time){


        		this.player.on('ready', () => {

        			globs.timer.time({ view : time, currentTime : this.player.getDuration() });

        			this.isPlayerReady = true;

        		});

        	},
        	playpause : function(time){

        		if(this.isPlayerReady){

        			this.player.playPause();

              this.playing = this.player.isPlaying() ? true : false

              console.log(this.playing)

        			this.player.on('audioprocess', () => {

        				// globs.timer.time({ view : time, currentTime : this.player.getCurrentTime() });

        			});


        		}

        	},
          

        },
        watch : {

          playing : function(nval, oval){

            console.log(nval, oval, this.makeIcon)

          }

        },
        mounted  : function(){

          console.log(this.player)

            this.player.load(this.post.getPost().url);

        	this.$nextTick(function(){

                this.isReady(this.timeView); // Init The Player To Ready Status

            });

        }

    };
</script>

<style scoped>

	.wrapper-audio{

		border: 0;
		width: 100%;

	}

  .app-fa{
   /* width: 28px;
    height: 28px;*/
  }

</style>
