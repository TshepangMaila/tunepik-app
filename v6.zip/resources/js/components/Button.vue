<template>
  <button :type="nativeType" :disabled="loading" :class="{
    [`btn-${type}`]: true,
    'btn-block': block,
    'btn-lg': large,
    'btn-loading': loading
  }" class="btn" :style="{ backgroundColor : backGroundColor, borderColor : theme.icons.color, color : textColor }"
  >
    <slot />
  </button>
</template>

<script>

import { mapGetters } from 'vuex'

export default {
  name: 'VButton',

  props: {
    type: {
      type: String,
      default: 'default'
    },

    nativeType: {
      type: String,
      default: 'submit'
    },

    loading: {
      type: Boolean,
      default: false
    },

    block: {
      type: Boolean,
      default: false
    },

    large: {
      type: Boolean,
      default: false
    }
  },
  computed : {

    ...mapGetters('tunepik', ['theme']),
    backGroundColor(){
      return this.type == 'default' ? '' : (this.theme.icons.color == this.theme.colors.light ? this.theme.colors.blue : this.theme.icons.color)
    },
    textColor : function(){
      
      if(this.type == 'default'){

        return this.theme.icons.color

      }

    }

  }
}
</script>
