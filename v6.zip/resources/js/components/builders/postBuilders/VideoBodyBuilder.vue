<template>

	<div class="app-image-body main-wrapper">

    <a class="media-anchor">

     <!--  <div class="embed-responsive embed-responsive-1by1"> -->

        <!-- <ImageBodyBuilder :post="post" v-show="!show" :thumb="true"></ImageBodyBuilder> -->

      	<video class="app-media app-video main-wrapper" ref="vid">

      		<source :src="post.getPost().url" />

      	</video>

        <div class="controls" v-show="show">
          
          <a @click="play()">
            
            <i class="fa fa-play app-fa" v-show="vid.paused"></i>
            <i class="fa fa-pause app-fa" v-show="vid.played"></i>

          </a>

        </div>

      <!-- </div> -->

    </a>

  </div>

</template>

<script>

  import globs from '../../../tunepik/attack.js'
  import ImageBodyBuilder from "./ImageBodyBuilder";

    export default {

        name    : "VideoBodyBuilder",
        data    : () => {

          return {

            screen : globs.app.isMobile,
            show   : false,

          }

        },
        components : {
          ImageBodyBuilder
        },
        props : ['post'],
      computed : {

          vid : function() {
            return this.$refs.vid
          }

      },
      methods : {

          play : function () {

            this.show = true

            this.vid.paused ? this.vid.play() : this.vid.pause()

          }

      }

    };
</script>

<style scoped>

</style>
