<template>

	<div class="wrapper">
		
		<SearchResults></SearchResults> 

	</div>
	
</template>

<script type="text/javascript">

	import SearchResults from '../../components/builders/SearchResults'
	
	export default {

		name : 'results',
		components : {

			SearchResults

		}

	};

</script>

<style type="text/css" scoped></style>