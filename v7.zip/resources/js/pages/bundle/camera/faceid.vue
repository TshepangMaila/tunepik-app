<template>
	
	 <div class="">
	 	<SetupFaceId></SetupFaceId>
	 </div>

</template>

<script type="text/javascript">

		import SetupFaceId from '../../../components/builders/cameraBuilders/SetupFaceId'

		export default {

			name 		: 'FaceId',
			components : {

				SetupFaceId

			}

		};

</script>

<style type="text/css" scoped></style>