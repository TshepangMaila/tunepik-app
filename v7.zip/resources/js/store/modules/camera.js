




export const state = {

	  camera : {
	  	permission : true
	  },
		video : {

			isRecording : false, 

		}

}

export const getters = {}

export const mutations = {}

export const actions = {

		init : function(){},
		startVideoFeed : function(_, tag){

			console.log(navigator)

			navigator.getUserMedia({ video : { aspectRatio : 16/9 } }, stream => {

				tag.srcObject = stream

			}, err => console.error(err))

		}

}