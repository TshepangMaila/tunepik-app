<template>


	    <div v-if="type == 'list'">

	    	<div class="" v-if="loading">

         <PostSkeleton></PostSkeleton>

       </div>
       <div class="" v-else>

          <div v-if="list" class="posts list-group" id="xxx">

            <template v-for="(PostModel, index) in posts">

              <post :post="PostModel" :comments="true" class="list-group-item no-border"></post>

            </template>

            <div class="app-load" :ref="'appLoader'">

              <center class="heartbroken" name="loader">
                <div class="app-loader"></div>
              </center>

            </div>
            <div class="space-large"></div><div class="space-large"></div><div class="space-large"></div>


         </div>
         <div v-else>

           <div class="space-large"></div>
           <div class="app-deleted-post grey-matter">

              <center>
              	<span class="app-small-text">
              		{{ message }}
              	</span>
              </center>

           </div>

         </div>

       </div>

	    </div>

	    <div v-else>

	    	GRIDD

	    </div>

</template>

<script>

   import Post from '../Post'
   import PostSkeleton from '../skeletonBuilders/PostSkeleton'
   import { mapActions, mapGetters } from 'vuex'

		export default {

			name    : "PostsBundler",
      data    : () => ({
        url   : '',
        loaded : true,
        loaderVisible : false,
      }),
			components : {

				Post,
        PostSkeleton

			},
			props   : ['posts', 'list', 'type', 'loading','message'],
      methods : {

        ...mapActions('tunepik', ['scroller']),
        ...mapActions('posts', ['getResults', 'getPosts']),
        ...mapActions('profile', ['getUserPosts', 'getLikedPosts']),
        makeInfiniteRequest : function(){

          let url = ''

          switch (this.$router.currentRoute.name) {

            case  'home'  :

              url = `/api/posts/feed/?last_id=${this.lastId}`
              this.getPosts(url)

              break;

            case 'profile' :

              url = this.profile.model ? `/api/posts/user/${this.profile.model.getBasic().id}/?last_id=${this.lastId}` : ''

              this.getUserPosts(url)

              break;

            case 'liked' :

              url = this.profile.model ? `/api/posts/user/${this.profile.model.getBasic().id}/?last_id=${this.lastId}}` : ''

              this.getLikedPosts(url)
              break;

            case 'results' :

              url = `/api/posts/search/feed/${this.$router.currentRoute.params.term}/?last_id=${this.lastId}`

              this.getResults(url)

              break;

          }

        }

      },
      computed : {

			  ...mapGetters('profile', ['profile']),
        lastId : function(){
			    return this.posts.length > 0 ? this.posts[this.posts.length - 1].getPost().id : 0
        },
        args : async function(){

          return  {

            callback : (isVisible) => {

                if(isVisible){

                  if(this.infite){

                    this.loaderVisible = true
                    

                    this.makeInfiniteRequest()

                    this.infite = false

                  }

                }else{

                  this.loaderVisible = false
                  this.infite = true

                }


              },
            element : await this.tag,
            inView  : true

          }


        },
        tag : async function(){

          const tags = await this.$el.getElementsByTagName('center')

          return tags.length > 0 ? tags[tags.length - 1] : 0
        }

        /*data : function(){

          return {

            options  : {
              threshold : 1.0,
              rootMargin : '0px'
            },
            callback : (entries, observer) => {

              entries.forEach((entry) => {

                console.log(entry)

                if(entry.intersectionRatio > 0.10){

                  // Call
                  console.log('inview!')
                  console.log(observer)
                  alert('Im SEEN')

                }else{
                  console.log('NAHHH')
                }

              })

            },
            target   : this.$el.getElementsByTagName('center')[0]

          }

        }
*/
      },/*
      mounted : function(){
      },*/
      watch : {

        loading : async function(load){

          if(!load){

            /*console.log(this.$el.getElementsByTagName('center').reverse()[0])*/
            console.log(this)

            this.scroller(await this.args)



          }

        },

      }


		};

</script>

<style scoped>

   .list-group-item{
    /*border : 0;
    border-bottom: .09em solid rgba(211, 211, 211, .5);*/
    padding-left: 0;
    padding-right: 0;
   }

</style>
