<template>
	
</template>

<script>

	export default {

		name 			: "UnFollowPop",
		props 		: ['show'],

	};
	
</script>

<style scoped>
	
</style>