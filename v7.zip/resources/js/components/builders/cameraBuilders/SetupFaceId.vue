<template>
	
	<div class="wrapper">

		<div class="video-view">
			
			<video class="video-tag" autoplay muted></video>

		</div>
		
		<div class="nav navbar fixed-bottom" style="background-color:transparent;z-index : 9999999">
			
			<div class="media">
				<div class="media-body">
					<center>
						<span class="app-post-text">recognising...</span>
					</center>
				</div>
			</div>

		</div>

	</div>


</template>

<script type="text/javascript">

	import { mapGetters, mapActions, mapMutations } from 'vuex'

	export default {

		name 	: 'SetupFaceId',
		methods : {

			...mapActions('camera',['startVideoFeed']),

		},
		computed : {

			videoTag : async function(){

			  let tag = await this.$el.getElementsByTagName('video')[0]
				return tag
			}

		},
		mounted : function(){
			this.$nextTick( async () => {

				this.videoTag.then(tag => {

					tag.controls = false

					this.startVideoFeed(tag)
				})

			})

		}

	};
	
</script>

<style type="text/css" scoped>


	.video-tag{
		width: 100%;
		height: 100%;
	}

	.wrapper,
	.video-tag{
		z-index: 9999 !important;
		position: fixed;
		top : 0;
		bottom: 0;
		left: 0;
		right: 0;
		width: 100%;
		height: 100%;
		overflow-y: auto;
		background-color: #fff;

	}
	
</style>