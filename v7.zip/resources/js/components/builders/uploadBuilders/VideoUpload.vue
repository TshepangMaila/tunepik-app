<template>

	<div>
		
		<Icon :icon="'vidupload'" :height="24" :width="24"></Icon>

	</div>
	
</template>

<script type="text/javascript">

  import { mapGetters, mapActions, mapMutations } from 'vuex'

	export default {

		name 	: "VideoUpload",

	};
	
</script>

<style type="text/css" scoped>
	
</style>