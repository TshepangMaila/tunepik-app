<template>

	<svg-vue :icon="" :style="[height, width]"
	
</template>

<script>

	
	export default {

		name 			: "Icon",
		props 		: ['icon', 'height', 'width']

	};

	
</script>

<style scoped>
	
</style>