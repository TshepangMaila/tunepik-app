<template>
	
		<div class="edit-account-wrapper">
			
			<div class="change-cover">
				
			</div>

			<div class="wrapper-info">
				
				<div class="card">

					<Navigation v-if="screen">
						
						<div class="media-body">
							
							<center>
								<span class="app-max-text">Account</span>
							</center>

						</div>
						<div class="media-right mr-2"></div>

					</Navigation>
					
					<div class="card-body p-3">

						 <div class="visible-xs space-large"></div>
						 <div class="visible-xs space-large"></div>
							
							<div class="media mb-4">
								
								<div class="media-left align-self-start">
								
									<img :src="'' + model.getImgs().profile" class="rounded-circle" height="75" width="75" />

								</div>
								<div class="media-body ml-4 align-self-center">
								
										<span class="app-max-text user-handle">@{{ model.getBasic().handle }}</span>

								</div>

							</div>

								<form>
										
										<div class="form-group" v-for="(item, key) in list">

											  <div class="info-wrapper" v-if="item.index == 1">
											  	
											  	<span class="app-max-text block-text">Public Information</span>
													<span class="app-grey-text-lg">
														Provide Your Public Infomation For People To Better Identify You And Discover Your Account Through Searching
													</span>
													<div class="space-small"></div>
													
											  </div>
												<div class="info-wrapper" v-if="item.index == 4">
													
													<span class="app-max-text block-text">Personal Information</span>
													<span class="app-grey-text-lg">
														Provide Your Personal Infomation. This Will Not Be Part Of Your Public Profile
													</span>
													<div class="space-small"></div>

												</div>
											
												<label :for="item.index" class="app-bolder-text">{{ item.header }}</label>

												<textarea class="form-control" :id="item.index" :name="item.name" :value="item.value" :placeholder="item.placeholder" v-if="item.index == 3">
													
												</textarea>

												<input type="text" :name="item.name" :id="item.index" class="form-control" :placeholder="item.placeholder" :value="item.value" v-else>

										</div>

								</form>

					</div>

				</div>

			</div>

		</div>

</template>

<script>
		
		import { mapGetters, mapActions } from 'vuex'
		import globs from '../../../../tunepik/attack.js'
		import Navigation from '../../../../components/mobile/root/Navigation'

		export default {

				name 			: "AccountBuilder",
				data 			: function(){
					return {

						screen  		: globs.app.isMobile,

					};
				},
				components : {

					Navigation

				},
				computed 	: {

					...mapGetters("auth", ['user']),
					model : function(){

						return new globs.model.user(this.user.model);

					},
					list 	: function(){

						return [

							{
								index   : 1,
								header  : 'Username',
								name 		: 'ch-name',
								value   : this.model.getBasic().name,
								placeholder : 'Change Username'
							},
							{
								index   : 2,
								header  : 'Location',
								name    : 'ch-location',
								value   : this.model.getInfo().location,
								placeholder : 'Add Location'
							},
							{
								index   : 3,
								header  : 'Bio',
								name 		: 'ch-bio',
								value   : this.model.getInfo().bio,
								placeholder : 'Edit Bio'
							},
							{
								index   : 4,
								header  : 'Email',
								name    : 'ch-email',
								value   : this.model.getBasic().email,
								placeholder : 'Change Email'
							}

						];

					}

				}

		};
	
</script>

<style scoped>


		@media only screen and (max-width: 700px){

			.edit-account-wrapper{
				z-index: 9999 !important;
				position: fixed;
				top : 0;
				bottom: 0;
				left: 0;
				right: 0;
				width: 100%;
				height: 100%;
				overflow-y: auto;
				background-color: #fff;

			}

		}
	
</style>