<template>

		<div class="wrapper">
			
			<center>

				<div class="wrapper-audio">
					
					<a @click="playpause()">

						<!-- <vue-wave-surfer ref="surf" :src="post.getPost().url" :options="options"></vue-wave-surfer> -->
				      <div class="wave-surf" id="surfer"></div>

					</a>

				</div>

			</center>
			<div class="media-info-body">
				<div class="media-text info-views">
					{{ timeView }}
				</div>
			</div>

		</div>
       
</template>

<script>

  import globs from '../../../tunepik/attack.js'
  import VueWaveSurfer from 'vue-wave-surfer'
  import WaveSurfer from 'wavesurfer.js'

    export default {

        name    		: "AudioBodyBuilder",
        components	: {

        	VueWaveSurfer

        },
        data    		: () => {

          return {

            screen : globs.app.isMobile,
            options : {
              container : '#surfer',
			  waveColor : '#5bc0de',
			  progressColor : '#111',
			  barWidth: 2,
    	      barHeight: 10,
    	      barRadius: 3,
    	      barGap: 2,
    	      height: 40,
    	      interact: false

    		},
			isPlayerReady : false,
			timeView 			: '00:00',

          }

        },
        props    : ['post'],
        computed : {

        	player : function(){

        		return WaveSurfer.create(this.options);

        	}

        },
        methods  : {

        	isReady   : function(){

        		this.player.on('ready', function(){

        			globs.timer.time({ view : this.timeView, currentTime : this.player.getDuration() });

        			this.isPlayerReady = true;

        		});

        	},
        	playpause : function(){

        		if(this.isPlayerReady){

        			this.player.playPause();

        			this.player.on('audioprocess', function(){

        				globs.timer.time({ view : this.timeView, currentTime : this.player.getCurrentTime() });

        			});


        		}

        	}

        },
        mounted  : function(){

        	this.$nextTick(function(){

                this.player.load(this.post.getPost().url);

                this.isReady(); // Init The Player To Ready Status

            });

        }

    };
</script>

<style scoped>

	.wrapper-audio{

		border-radius: 20px;
		border: .05em solid lightgrey;
		width: 90%;

	}

</style>
