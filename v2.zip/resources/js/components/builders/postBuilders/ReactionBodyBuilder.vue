<template>

  <div class="app-react-body container-fluid">

    <div class="media">
      
      <!-- Wrapper For React Icons -->
      <div class="react-round">
        
        <!-- For Liking -->
        <a href="#" class="p-1">
          
          <span class="like-icon-wrapper">
              
              <svg-vue icon="heartEmpty" class="app-icon react-icon"></svg-vue>

          </span>
          
          <!-- <span class="app-bold-text pt-1" v-if="post.getStats().likeCount > 0">{{ post.getStats().likeCount }}</span> -->

        </a>

        <!-- For Commenting -->
        <router-link :to="{ name : 'comment', params : { username : post.getBasic().handle, id : post.getPost().id, type : post.getPost().type } }" >
          
          <span class="comment-icon-wrapper p-1">
            
            <svg-vue icon="comment" class="app-icon react-icon"></svg-vue>

          </span>

        </router-link>

        <!-- For Sharing -->
        <a v-on:click="toggleShareP()" class="p-1">
          
          <span class="share-icon-wrapper">
            
             <svg-vue icon="share" class="app-icon react-icon"></svg-vue>

          </span>

        </a>

      </div>

      <!-- Wrapper Prolly For Date, If Not Empty -->
      <div class="media-body">

      </div>

      <!-- Wrapper For External Sharing -->
      <div class="align-self-center">
        
        <a v-on:click="toggleShareX()" class="pl-1">
          
          <span class="x-share-icon-wrapper">
            
            <svg-vue icon="xshare" class="app-icon" style="height:16px;width:16px;"></svg-vue>

          </span>

        </a>

      </div>

    </div>

    <div class="counter-wrapper">

      <div class="media mt-1" v-if="post.getStats().likeCount > 0">
        
        <div class="media-left align-self-center" v-if="post.getStats().likedBy != ''">

          <img :src="post.getStats().likedBy.user.getImgs().profile" class="rounded-circle" width="20" height="20" />
          
        </div>
        <div class="media-body align-self-center ml-1">


          <span v-if="post.getStats().likedBy != '' && post.getStats().likeCount == 1">
            
            <span class="app-grey-text-lg">
              Liked by
            </span>
            <span class="app-bold-text">
              {{ post.getStats().likedBy.user.getBasic().handle }} 
            </span>

          </span>
          <span v-else-if="post.getStats().likedBy != '' && post.getStats().likeCount >= 2">
            
            <span class="app-grey-text-lg">
              Liked by
            </span>
            <span class="app-bold-text">
              {{ post.getStats().likedBy.user.getBasic().handle }} 
            </span>
            <span class="app-grey-text-lg">
              and
            </span>
            <span class="app-bold-text">
              {{ post.getStats().likeCount - 1 }}
              <span v-if="post.getStats().likeCount == 2">
                other
              </span>
              <span v-else>
                others
              </span>
            </span>


          </span>
          <span v-else>
            
            <span class="app-bolder-text">{{ post.getStats().likeCount }}</span>
            <span class="app-grey-text-lg" v-if="post.getStats().likeCount > 1"> likes</span>

          </span>

        </div>

      </div>

        <span v-if="post.getStats.comCount > 0">

            <span class="app-bolder-text ml-2">{{ post.getStats().comCount }}</span>
            <span class="app-grey-text-lg" v-if="post.getStats.comCount > 1"> comments</span>
            <span class="app-grey-text-lg" v-else-if="post.getStats.comCount == 1"> commented</span>

        </span>

     </div>


     <!-- SHARE POST EXTERNALLY POP UP -->
     <PostPopUp :show="showShareX" v-if="screen">

       <ShareXPop :post="post"></ShareXPop>

     </PostPopUp>
     <PopUpWindow :headerText="shareXHeader" :show="showShareX" v-else>

      <ShareXPop :post="post"></ShareXPop>

     </PopUpWindow>


     <!-- SHARE POST INTERNALLY POP UP -->
     <PopUpWindow :headerText="sharePHeader" :show="showShareP">
       
       <SharePostPop :post="post"></SharePostPop>

     </PopUpWindow>



  </div>
       
</template>

<script>

  import globs from '../../../tunepik/attack.js'
  import PopUpWindow from '../popupBuilders/PopUpWindow'
  import ShareXPop from '../popupBuilders/ShareXPop'
  import SharePostPop from '../popupBuilders/SharePostPop'
  import PostPopUp from '../popupBuilders/PostPopUp'

    export default {

        name        : "ReactionBodyBuilder",
        components  : {

            PopUpWindow,
            ShareXPop,
            SharePostPop,
            PostPopUp

        },
        data        : () => {

          return {

            screen      : globs.app.isMobile,
            shareXHeader : 'Share Post',
            showShareX   : false,
            showShareP   : false,

          }

        }, 
        props       : ['post'],
        methods     : {

            toggleShareX  : function(){

              this.showShareX = !this.showShareX;

            },
            toggleShareP  : function(){

              this.showShareP = !this.showShareP;

            }

        },
        computed    : {

            sharePHeader : function(){

              return `Share @${this.post.getBasic().handle} Post`;

            },

        }


    };
</script>

<style scoped>

  .react-round{

    border-radius: 20px;
    padding: 5px;
    -webkit-box-shadow: 0 .5px 1px rgba(0, 0, 0, .175);
    box-shadow: 0 .5px 1px rgba(0, 0, 0, .175);

  }

  .react-count-wrapper{

    border: .05em solid rgba(211, 211, 211, .175)

  }

  .app-react-body{



  }

  .react-icon{

    width : 20px;
    height : 20px;

  }

</style>
