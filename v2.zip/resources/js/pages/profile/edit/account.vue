<template>

	<AccountBuilder></AccountBuilder>
	
</template>

<script>
		
		import AccountBuilder from '../../../components/builders/profileBuilders/edit/AccountBuilder'

		export default {

				name 				: "Account",
				components 	: {

					AccountBuilder

				}

		};
	
</script>

<style scoped>
	
</style>