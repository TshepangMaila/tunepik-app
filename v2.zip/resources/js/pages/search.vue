<template>

	<div class="wrapper">

		<Navigation class="navbar fixed-top bg-white">

			<div class="media-body ml-1">
				
				<div class="search-wrapper">

					<form>

						<table class="">

							<tr>
								<td class="pl-2">
									<input type="search" v-on:keyup="query = $event.target.value" name="search" class="xs-search app-search" placeholder="search tunepik..." />
								</td>
								<td class="pr-1">
									<center>
										<span class="search icon-wrapper">
						
										  <svg-vue icon="search" class="search-icon app-icon" style="width:22px;height:22px"></svg-vue>

									  </span>
									</center>
								</td>
							</tr>

						</table>
					</form>
					
				</div>

				</div>

		</Navigation>

		<div class="space-large"></div>
		<div class="space-medium"></div>

		<div class="search-results">
				
				<SearchView :q="query"></SearchView>

		</div>

		<div class="search-extend">
			
			<MobileSuggestions></MobileSuggestions>

		</div> 

		<div class="space-large"></div>
		<div class="space-medium"></div>
		<div class="space-large"></div>
		<div class="space-medium"></div>

	</div>
	
</template>

<script>

	import MobileSuggestions from '../components/mobile/root/MobileSuggestions'
	import SearchView from '../components/builders/SearchView'
	import Navigation from '../components/mobile/root/Navigation'

  export default {

  	name : "Search",
  	scrollToTop : false,
  	data : function(){

  		return {

  			query : ''

  		}

  	},
  	components : {

  		MobileSuggestions,
  		SearchView,
  		Navigation

  	},

  };
	
</script>

<style scoped>

   .search-wrapper{

   	border : .05em solid rgba(211, 211, 211, .4);
   	border-radius: 15px;
   	padding: 2px;
   	width: 100%;

   }

   table{
   	width : 100%;
   }
	
</style>