<template>
    
    <ProfileBundler></ProfileBundler>
       
</template>

<script>

  import ProfileBundler from '../../components/builders/profileBuilders/ProfileBundler'

    export default {

        name    : "Profile",
        scrollToTop : false,
        components : {

        	ProfileBundler

        }

      }
</script>

<style scoped>

</style>
